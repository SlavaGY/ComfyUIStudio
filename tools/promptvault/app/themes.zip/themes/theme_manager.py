import sys
from pathlib import Path

from PySide6.QtCore import QSettings
from PySide6.QtWidgets import QApplication

# см. подробный комментарий у аналогичного кода в app/config.py
# (ICON_PATH/TRANSLATIONS_DIR) — Path(__file__).resolve().parent сам
# по себе не находит файлы внутри сборки PyInstaller, нужен
# sys._MEIPASS.
if getattr(sys, "frozen", False) and hasattr(sys, "_MEIPASS"):
    THEMES_DIR = Path(sys._MEIPASS) / "app" / "themes"
else:
    THEMES_DIR = Path(__file__).resolve().parent

# отображаемое имя -> имя файла в этой же папке
AVAILABLE_THEMES = {
    "Dark": "dark.qss",
    "Light": "light.qss",
    "Nord": "nord.qss",
    "Catppuccin Mocha": "catppuccin.qss",
    "Dracula": "dracula.qss",
    "GitHub Dark": "github_dark.qss",
}

DEFAULT_THEME = "Dark"

# контрастный цвет (совпадает с основным цветом текста темы) для кружка
# кнопки-переключателя тем: тёмный кружок на светлой теме, светлый — на тёмной
CIRCLE_COLORS = {
    "Dark": "#e0e0e0",
    "Light": "#1e1e1e",
    "Nord": "#ECEFF4",
    "Catppuccin Mocha": "#cdd6f4",
    "Dracula": "#f8f8f2",
    "GitHub Dark": "#c9d1d9",
}


class ThemeManager:
    """Загружает QSS-темы и применяет их ко всему приложению.

    Последняя выбранная тема запоминается через QSettings и
    восстанавливается при следующем запуске.
    """

    def __init__(self):
        self._settings = QSettings("PromptVault", "PromptVault")
        self._cache = {}

    # --------------------------------------------------

    def available_themes(self):
        """Список отображаемых имён тем в фиксированном порядке."""

        return list(AVAILABLE_THEMES.keys())

    # --------------------------------------------------

    def current_theme(self):
        """Имя темы, сохранённой с прошлого запуска (или тема по умолчанию)."""

        saved = self._settings.value("theme", DEFAULT_THEME)

        if saved not in AVAILABLE_THEMES:
            return DEFAULT_THEME

        return saved

    # --------------------------------------------------

    def circle_color(self, theme_name):
        """Контрастный цвет для круглой кнопки-переключателя тем."""

        return CIRCLE_COLORS.get(theme_name, "#ffffff")

    # --------------------------------------------------

    def load_stylesheet(self, theme_name):
        """Возвращает содержимое .qss файла темы (с кэшированием)."""

        if theme_name not in AVAILABLE_THEMES:
            theme_name = DEFAULT_THEME

        if theme_name in self._cache:
            return self._cache[theme_name]

        path = THEMES_DIR / AVAILABLE_THEMES[theme_name]

        try:
            stylesheet = path.read_text(encoding="utf-8")
        except OSError:
            stylesheet = ""

        self._cache[theme_name] = stylesheet

        return stylesheet

    # --------------------------------------------------

    def apply_theme(self, theme_name, app=None):
        """Применяет тему ко всему приложению и запоминает выбор."""

        if app is None:
            app = QApplication.instance()

        if app is None:
            return

        app.setStyleSheet(self.load_stylesheet(theme_name))

        self._settings.setValue("theme", theme_name)
